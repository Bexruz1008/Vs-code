# Front-end Style Guide

## Layout

The designs were created to the following widths:

- Mobile: 375px
- Desktop: 1440px

> 💡 These are just the design sizes. Ensure content is responsive and meets WCAG requirements by testing the full range of screen sizes from 320px to large screens.

## Colors

### Primary

- Navy 850 (intro and email sign up background): #1c2431
- Navy 900 (main background): #181f2a
- Navy 950 (footer background): #0b1523
- Navy 800 (testimonials background): #202a3c

### Accent

- Teal 200 (inside call-to-action gradient): #65e2d9
- Cyan 500 (inside call-to-action gradient): #339ecc
- Red 500 (error): #ff4242

### Neutral

- White: #ffffff

## Typography

### Body Copy

- Font size: 14px

### Headings, Call-to-actions, Header Navigation

- Family: [Raleway](https://fonts.google.com/specimen/Raleway)
- Weights: 400, 700

### Body

- Family: [Open Sans](https://fonts.google.com/specimen/Open+Sans)
- Weights: 400, 700

## Icons

For the social icons, you can use a font icon library. Some suggestions can be found below:

- [Font Awesome](https://fontawesome.com/)
- [IcoMoon](https://icomoon.io/)
- [Ionicons](https://ionicons.com/)

