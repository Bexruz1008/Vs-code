function changeText() {
    const paragraph = document.getElementById("matn1");
    paragraph.textContent = "Yangi matn";
}
function changeColor() {
    const sarlavha = document.getElementById("sarlavha1");
    sarlavha.style.color = "red";
}
function showName() {
    const input = document.getElementById("input1");
    const result = document.getElementById("ism");
    result.textContent = input.value;
}

function addItem() {
    const newItem = document.createElement("li");
    newItem.textContent = "Yangi element";
    document.getElementById("itemList").appendChild(newItem);
}


function hideText() {
    document.getElementById("Text").style.display = "none";
}

function showText() {
    document.getElementById("Text").style.display = "block";
}


